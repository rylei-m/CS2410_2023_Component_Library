function toggleDrawer() {
    var drawer = document.getElementById("navigationDrawer");
    drawer.classList.toggle("open");
}
